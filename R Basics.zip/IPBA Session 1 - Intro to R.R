# ---Intro to R---

# This is my first R session
# I am looking for some case studies
# Some more comment
# some more comment

# www.rseek.org

print ("Hello batch 3 of IPBA")
print(2)

# How to get to know more about print function

?print
help(print)

# Aritmatic operations
2+2
10*3
10^3 # exp
20/0.6

# modulo operator - remainder part after division
20 %% 0.6

# integer part of div
20 %/% 0.6

# integer part of div
print(20 %/% 0.6)


# Function in R

# funname(arg1= , arg2=, ....)

sum(1,2,3,4,5)

mean(1,2,3,4,5)
# I need to think of COMBINING above 5 values to represent one object
# I have to use what is known as combinig operator - c
?mean

?sum

mean(c(1,2,3,4,5))

# Get the sum of all the numbers from 1 to 999
sum(1:999)

# Get log of 1000
log(500, base = 10)

# How do we create objects in R
# Assignment operator
# <- or =
#Assign a value of 10 to object p

p <- 10

q <- 25

p+q


# Store - Tees and Shirts

# Day 1
Sales_tees <- 60
Sales_shirts <- 45

ttl_sales <- Sales_shirts + Sales_tees

# Overwrite the value of the objects

# Day 2
Sales_tees <- 35
Sales_shirts <- 50

ttl_sales <- Sales_shirts + Sales_tees

p <- "Jigsaw"

# Various types of objects/ data structure in R
# Vectors

#The most simplest data structures in R
# It consists of one or more set of values
# It must contain all the values of only one data type

# Numeric
vec1 <- c(1,2,3,5,7)

#char
vec2 <- c("Adidas", "Puma", "nike")

# Logical
vec3 <- c(TRUE,FALSE,TRUE,TRUE)

# Mixed vector
vecMix <- c(1,2,3,"ADIDAS", TRUE)
vecMix <- c(1,2,3, TRUE, FALSE)

# This is known as precedence of data types
# Char > Num > Logical

# Misssing values in R
#Create 3 vectors with 5 elements in each
# 1. Customer name
# 2. Age and 
# 3. wether or not Customer defaulted in paying loan


# 1. Customer name
Customer_Name<-c('Sam','Nick','Chris','Joe','Amenda')
Customer_Name

# What is the class (data type) of above vector?
class(Customer_Name)

#How many elements are there in the vector?
length(Customer_Name)

# 2. Age
Customer_Age<-c(18,25,34,NA,17)
Customer_Age
class(Customer_Age)
length(Customer_Age)

# 3. wether or not Customer defaulted in paying loan
Customer_Default<-c(TRUE,FALSE,TRUE,FALSE,NA) 
Customer_Default
class(Customer_Default)
length(Customer_Default)

# How to identify if I have missing values in my data

is.na(Customer_Name)
is.na(Customer_Age)
is.na(Customer_Default)

# How to count # of missing values
#TRUE - 1
#FALSE - 0

sum(is.na(Customer_Name))
sum(is.na(Customer_Age))
sum(is.na(Customer_Default))

# Arithmetic operations on vectors
a1<-c(1,1,1)
a2<-c(2,2,NA)
a1+a2

# Try introducing an NA in one of the above vectors and check results

# Say I have 2 numeric vectors with score of 2 players in 5 ODIs
Player1 <- c(24,51,45,70,19)
Player2 <- c(34,72,11,70,56)

# Get the count of matches in which Player one has scored half centuries

pl1_logical <- Player1 >=50
sum(pl1_logical)

sum(Player1>=50)

# Get # of matches in which player 2 has done better than player 1

sum(Player2 > Player1)


# Travesing in data/ searching the elements/ data points in a data structures

brands <- c("Adidas", "Nike", "Sketchers", "Puma", "NewBalance")

#Index
# [x]
brands[3]

# First 2 brands in the vector
brands[1:2]

# Find brands at position 2 and 4

brands[c(2,4)]

brands[-1]

brands[-1:-3]

brands[c(-1,-3)]

# Matrix and Dataframes
# Matrix

# multiple vectors arranged in row and col ways
# All the elements of a matrix have to be of the same data type


matrix1 <- matrix(c(1,2,3,1,5,7),
                  nrow = 4, 
                  ncol = 3)
matrix1

# travesing
# [row index, col index]
matrix1[,2]

matrix1[2,]

matrix1[2,3]

# Dataframes
# All the vectors/ columns have to be of the same length
# However vectors can be of different data types

product=c("Bag","shoes","belt","belt")

total_price=c(500,1000,150,10000)

color=c("Blue","red","red","blue")

quantity=c(5,2,3,4)

#Creare a dataframe
product_details <- data.frame(product,total_price,color,quantity,
                              stringsAsFactors=FALSE)

#Understand the idea of StringsAsFactors
product_details <- data.frame(product,total_price,color,quantity)

product_details

View(product_details)

class(vec1)

class(matrix1)

class(product_details)

# Travesing in data frame

product_details[,2]

product_details[,"total_price"]

product_details$total_price

product_details["total_price"]

subset_pd<- product_details[,c("total_price", "quantity")]

#class(product_details["product"])

# Lists

#Lists : Recursive vectors. 
#Can handle different data types oF various sizes
my.list <- list( name = c("Robert", "Emma"), age = c (65, 54,43),
                 retired = c (TRUE, FALSE))

#Note the $ sign against each variable to distinguish the output as list variables
my.list

#To get a variable out of the list - 2 ways
my.list$age
my.list["age"]

vec1 <- c(1,2,3)
vec1[2]

class(my.list$age)
class(my.list["age"])

#Check list class. Note the difference
class(my.list$age)
class(my.list["age"])

my.list$age[2]

# double ref
my.list[["age"]][2]

# position of an element
which()

my.list[["age"]][2]
# Getting 2nd entity inside variable Age of my.lsit. This is double referencing
my.list[["age"]][2]

# Double square brackets are a must when we do double referencing
my.list[[3]]
my.list [[3]][2]

sales <- c(461,574,238,607,829,614,714,703,690,163,859,377,128,4500)

bp_sales <- boxplot(sales)
class(bp_sales)

bp_sales$out

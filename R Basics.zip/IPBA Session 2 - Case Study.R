# Case study

# Context----
# You are working with an e-commerce retailer that sells various grocery products 
# across various categories. Orders are placed by various customers and
# thus are fulfilled by the retailer through various shipments via 
# pre identified set of shippers through the retailer warehouses.

# Q1.
# Can you conclude that the average sales per day for the retailer has
# increased from Year 1 to Year 2? If yes, can you also arrive at similar conclusions
# for various categories that are selling? Also note that Year 1 is all the orders
# between 01 Jul 2006 and 30 Jun 2007 and rest is Year 2

# Business understanding
# Approach - how do you wnat to solve that

# set the working dir
setwd("C:\\Users\\DELL\\Documents\\Jigsaw Courses\\Courses\\R Basics")


# Import the data

# To read a file correctly in R, you have to ensure
# 1. Header is defined
# 2. Missing values are read as NA's
# 3. All the data types are correctly defined


orders <- read.csv("Orders.csv", header = TRUE, stringsAsFactors = FALSE, 
                   na.strings = "")

orderDetails<- read.csv("Orderdetails.csv", header = TRUE, stringsAsFactors = FALSE,
                        na.strings = "")

categories <- read.csv("categories.csv",header = TRUE, stringsAsFactors = FALSE,
                       na.strings = "")

products <- read.csv("products.csv", header = TRUE, stringsAsFactors = FALSE,
                     na.strings = "")

# Check if there are missing values in the data


sum(is.na(orders$orderid))

colSums(is.na(orders))

#Checking for missing values
colSums(is.na(orders))

colSums(is.na(orderDetails))

colSums(is.na(categories))

colSums(is.na(products))

# No missing value treatment required


# Checkng data types if they rae correct

str(orders)
str(orderDetails)
str(products)
str(categories)


# Date manipulation

# Lubridate

install.packages("lubridate")

# Use lubridate lib in this instance of R studio
library(lubridate)

orders$orderdate <- ymd_hms(orders$orderdate)

class(orders$orderdate)

str(orders)

install.packages("dplyr")

library(dplyr)

# Data manipluation

# 1. sorting
# 2. filering
# 3. grouping/ rolling up
# 4. adding new columns, deleting columns from the data
# 5. Data transformations - sales -- sqrt(sales)
# 6. Merging (joining the datas using Primary key and sec keys)
# 7. Selecting data which is req


# Join the data frames
# 2 tables - L and R
# Key
# LJ, RJ, OJ, IJ
#merge(x,y, by = "", all.x)

# Selecting your req data
select(categories, categoryid, categoryname)

prodCat <- merge(x= select(categories, categoryid, categoryname), 
                 y = select (products, productid, categoryid),
                 by = "categoryid")

# Join the order details table with product Category info table above
orderProdCat <- merge(x= orderDetails, 
                      y = prodCat, 
                      by = "productid")

# Joining above resultant table with orders table to get order date
ProdCatDate <- merge(x= select(orders, orderid, orderdate),
                            y = orderProdCat,
                            by = "orderid")

# Sales numbers
ProdCatDate$Sales <- ProdCatDate$qty*ProdCatDate$unitprice

# Roll of of sales data at order date level - total sales

# group_by()
# summarize

# GROUP BY LEVEL - order date
# WHat summarization - sum, mean
# WHAT VAR YOU WNAT TO SUMMARIZE - sales

ProdCatDateGp <- group_by(ProdCatDate, orderdate)

# summarize

final_sales<- summarize(ProdCatDateGp, t_sales = sum(Sales))

# Geting 2 years of data
sales_Y1 <- filter(final_sales, orderdate <= '2007-06-30' )
sales_Y2 <- filter(final_sales, orderdate > '2007-06-30' )

mean(sales_Y1$t_sales)

mean(sales_Y2$t_sales)


# WHAT statistical test you would do in thois case

# 2 sample t test

# H0 - Avg sales of Y1 = Avg sales of Y2
# H1- Avg y2 > Av y1
# alpha - 0.05
# P < 0.05 - Reject H0 / Accept H1
# P > 0.05 - Fail to reject H0/ Accept H0


t.test(sales_Y1$t_sales, sales_Y2$t_sales, 
       alternative = "less", var.equal = TRUE )



# -- Testing the increase of sales for each category

# Roll up the data at Category Date level to get total sales, total qty and avg price
CatSalesByDateGP <- group_by(ProdCatDate, categoryid, orderdate)

# Summarize the data in this step
finalCatSales <- summarize(CatSalesByDateGP, 
                           t_sales = sum(Sales),
                           t_qty= sum(qty), 
                           m_Pr = mean(unitprice))

# Geting 2 years of data
sales_Cat_Y1 <- filter(finalCatSales, orderdate <= '2007-06-30' )
sales_Cat_Y2 <- filter(finalCatSales, orderdate > '2007-06-30' )


df[row,col]

sales_Cat_Y1 <- as.data.frame(sales_Cat_Y1)
sales_Cat_Y2 <- as.data.frame(sales_Cat_Y2)


t.test(sales_Cat_Y1[sales_Cat_Y1$categoryid == 2, "t_sales"],
       sales_Cat_Y2[sales_Cat_Y2$categoryid == 2, "t_sales"],
       alternative = "less", var.equal = TRUE)

